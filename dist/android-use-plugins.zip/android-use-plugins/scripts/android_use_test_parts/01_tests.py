# Loaded by scripts/test_android_use_mcp.py. Keep this file below 2000 lines.

class AndroidUseMcpTestsPart1(unittest.TestCase):
    def test_parse_adb_devices(self) -> None:
        output = """List of devices attached
emulator-5554 device product:sdk_gphone64_arm64 model:sdk_gphone64_arm64 device:emu64a transport_id:1
abc123 unauthorized usb:336592896X
"""
        devices = mcp.parse_adb_devices(output)

        self.assertEqual(devices[0]["serial"], "emulator-5554")
        self.assertEqual(devices[0]["state"], "device")
        self.assertEqual(devices[0]["details"]["model"], "sdk_gphone64_arm64")
        self.assertEqual(devices[1]["state"], "unauthorized")

    def test_parse_adb_mdns_services(self) -> None:
        output = """List of discovered mdns services
adb-ANMB._adb-tls-connect._tcp.    172.27.31.51:37123
adb-ANMB._adb-tls-pairing._tcp.    172.27.31.51:44111
"""
        services = mcp.parse_adb_mdns_services(output, host="172.27.31.51")

        self.assertEqual(services, [
            {
                "service": "adb-ANMB._adb-tls-connect._tcp.    172.27.31.51:37123",
                "service_name": "adb-ANMB",
                "service_type": "_adb-tls-connect._tcp",
                "host": "172.27.31.51",
                "port": 37123,
                "serial": "172.27.31.51:37123",
            }
        ])

    def test_parse_adb_mdns_pairing_services_matches_qr_session(self) -> None:
        output = """List of discovered mdns services
studio-AbC123xYz9          _adb-tls-pairing._tcp  192.168.86.39:55861
adb-ANMB9X5A10G00857      _adb-tls-connect._tcp  192.168.86.39:37123
"""
        services = mcp.parse_adb_mdns_pairing_services(output, service_name="studio-AbC123xYz9")

        self.assertEqual(len(services), 1)
        self.assertEqual(services[0]["service_name"], "studio-AbC123xYz9")
        self.assertEqual(services[0]["service_type"], "_adb-tls-pairing._tcp")
        self.assertEqual(services[0]["host"], "192.168.86.39")
        self.assertEqual(services[0]["port"], 55861)

    def test_choose_serial_no_device_guidance_mentions_wired_wireless_and_qr(self) -> None:
        original_list_devices = mcp.list_devices
        original_auto_reconnect = mcp.auto_reconnect_wireless_if_needed
        try:
            mcp.list_devices = lambda: []
            mcp.auto_reconnect_wireless_if_needed = lambda: None

            with self.assertRaises(mcp.AndroidUseError) as context:
                mcp.choose_serial()
        finally:
            mcp.list_devices = original_list_devices
            mcp.auto_reconnect_wireless_if_needed = original_auto_reconnect

        message = str(context.exception)
        self.assertIn("有线", message)
        self.assertIn("无线", message)
        self.assertIn("android_wireless_pair_qr", message)

    def test_tool_list_devices_returns_connection_help_when_empty(self) -> None:
        original_list_devices = mcp.list_devices
        try:
            mcp.list_devices = lambda: []

            content = mcp.tool_list_devices({"include_details": False})
        finally:
            mcp.list_devices = original_list_devices

        payload = json.loads(content[0]["text"])
        self.assertEqual(payload["devices"], [])
        self.assertEqual(payload["connection_help"]["methods"][0]["name"], "有线连接")
        self.assertEqual(payload["connection_help"]["methods"][1]["name"], "无线连接")

    def test_wireless_pair_qr_create_returns_session_and_png(self) -> None:
        original_android_dir = mcp.ANDROID_USE_DIR
        original_screen_dir = mcp.SCREEN_DIR
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                mcp.ANDROID_USE_DIR = Path(tmpdir) / ".android-use"
                mcp.SCREEN_DIR = Path(tmpdir) / ".screen"

                content = mcp.tool_wireless_pair_qr({"action": "create"})
                payload = json.loads(content[0]["text"])
                png = mcp.base64.b64decode(content[1]["data"])

                self.assertEqual(content[1]["type"], "image")
                self.assertEqual(content[1]["mimeType"], "image/png")
                self.assertTrue(payload["session_id"])
                self.assertTrue(payload["service_name"].startswith("studio-"))
                self.assertTrue(payload["qr_payload"].startswith("WIFI:T:ADB;S:studio-"))
                self.assertTrue(Path(payload["qr_path"]).exists())
                self.assertEqual(mcp.png_size(png), {"width": 328, "height": 328})
        finally:
            mcp.ANDROID_USE_DIR = original_android_dir
            mcp.SCREEN_DIR = original_screen_dir

    def test_wireless_pair_qr_complete_pairs_discovered_service(self) -> None:
        original_android_dir = mcp.ANDROID_USE_DIR
        original_run_command = mcp.run_command
        original_reconnect = mcp.wireless_reconnect
        commands: list[list[str]] = []
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                mcp.ANDROID_USE_DIR = Path(tmpdir) / ".android-use"
                mcp.save_wireless_qr_session(
                    {
                        "session_id": "session-1",
                        "service_name": "studio-AbC123xYz9",
                        "password": "Pass12345678",
                        "qr_payload": "WIFI:T:ADB;S:studio-AbC123xYz9;P:Pass12345678;;",
                        "qr_path": str(Path(tmpdir) / "qr.png"),
                        "created_at": "2026-05-30T00:00:00Z",
                        "completed_at": None,
                    }
                )

                def fake_run_command(command: list[str], **_kwargs: object) -> tuple[bytes, bytes]:
                    commands.append(command)
                    if command[1:3] == ["mdns", "services"]:
                        return (
                            b"List of discovered mdns services\n"
                            b"studio-AbC123xYz9          _adb-tls-pairing._tcp  192.168.86.39:55861\n",
                            b"",
                        )
                    if command[1] == "pair":
                        self.assertEqual(command[2], "192.168.86.39:55861")
                        self.assertEqual(command[3], "Pass12345678")
                        return b"Successfully paired", b""
                    raise AssertionError(command)

                def fake_reconnect(**kwargs: object) -> dict[str, object]:
                    self.assertEqual(kwargs["host"], "192.168.86.39")
                    self.assertTrue(kwargs["save"])
                    self.assertTrue(kwargs["start_scrcpy"])
                    return {"ok": True, "serial": "192.168.86.39:37123"}

                mcp.run_command = fake_run_command
                mcp.wireless_reconnect = fake_reconnect

                content = mcp.tool_wireless_pair_qr(
                    {"action": "complete", "session_id": "session-1", "timeout_sec": 1}
                )
                payload = json.loads(content[0]["text"])
        finally:
            mcp.ANDROID_USE_DIR = original_android_dir
            mcp.run_command = original_run_command
            mcp.wireless_reconnect = original_reconnect

        self.assertEqual(payload["pair_target"], "192.168.86.39:55861")
        self.assertEqual(payload["reconnect"]["serial"], "192.168.86.39:37123")
        self.assertTrue(any(command[1] == "pair" for command in commands))

    def test_wireless_configs_from_env_reads_multiple_devices_and_legacy(self) -> None:
        original_read = mcp.read_user_env_values
        original_env = {
            "ANDROID_USE_WIRELESS_DEVICES": mcp.os.environ.get("ANDROID_USE_WIRELESS_DEVICES"),
            "ANDROID_USE_WIRELESS_HOST": mcp.os.environ.get("ANDROID_USE_WIRELESS_HOST"),
            "ANDROID_USE_WIRELESS_PORT": mcp.os.environ.get("ANDROID_USE_WIRELESS_PORT"),
            "ANDROID_USE_SERIAL": mcp.os.environ.get("ANDROID_USE_SERIAL"),
            "ANDROID_SERIAL": mcp.os.environ.get("ANDROID_SERIAL"),
        }
        try:
            for key in original_env:
                mcp.os.environ.pop(key, None)
            mcp.read_user_env_values = lambda: {
                "ANDROID_USE_WIRELESS_DEVICES": "10.0.0.1:5555,10.0.0.2:4444",
                "ANDROID_USE_WIRELESS_HOST": "10.0.0.3",
                "ANDROID_USE_WIRELESS_PORT": "3333",
                "ANDROID_SERIAL": "10.0.0.3:3333",
            }

            configs = mcp.wireless_configs_from_env()
        finally:
            mcp.read_user_env_values = original_read
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(
            [(item["host"], item["port"], item["serial"]) for item in configs],
            [
                ("10.0.0.1", 5555, "10.0.0.1:5555"),
                ("10.0.0.2", 4444, "10.0.0.2:4444"),
                ("10.0.0.3", 3333, "10.0.0.3:3333"),
            ],
        )

    def test_save_wireless_config_appends_multi_device_and_resident_serials(self) -> None:
        original_read = mcp.read_user_env_values
        original_update = mcp.update_user_env_file
        original_env = {
            "ANDROID_USE_WIRELESS_DEVICES": mcp.os.environ.get("ANDROID_USE_WIRELESS_DEVICES"),
            "ANDROID_USE_SCRCPY_RESIDENT_SERIALS": mcp.os.environ.get("ANDROID_USE_SCRCPY_RESIDENT_SERIALS"),
        }
        captured: dict[str, str] = {}
        try:
            for key in original_env:
                mcp.os.environ.pop(key, None)
            mcp.read_user_env_values = lambda: {
                "ANDROID_USE_WIRELESS_DEVICES": "10.0.0.1:5555",
                "ANDROID_USE_SCRCPY_RESIDENT_SERIALS": "10.0.0.1:5555,usb-1",
            }
            mcp.update_user_env_file = lambda updates: captured.update(updates)

            mcp.save_wireless_config("10.0.0.2", 4444, "10.0.0.2:4444")
        finally:
            mcp.read_user_env_values = original_read
            mcp.update_user_env_file = original_update
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(captured["ANDROID_USE_WIRELESS_HOST"], "10.0.0.2")
        self.assertEqual(captured["ANDROID_USE_WIRELESS_PORT"], "4444")
        self.assertEqual(captured["ANDROID_USE_WIRELESS_DEVICES"], "10.0.0.1:5555,10.0.0.2:4444")
        self.assertEqual(captured["ANDROID_USE_SERIAL"], "10.0.0.2:4444")
        self.assertEqual(captured["ANDROID_SERIAL"], "10.0.0.2:4444")
        self.assertEqual(captured["ANDROID_USE_SCRCPY_RESIDENT_SERIALS"], "10.0.0.1:5555,usb-1,10.0.0.2:4444")

    def test_save_wireless_config_replaces_stale_port_for_same_host(self) -> None:
        original_read = mcp.read_user_env_values
        original_update = mcp.update_user_env_file
        original_env = {
            "ANDROID_USE_WIRELESS_DEVICES": mcp.os.environ.get("ANDROID_USE_WIRELESS_DEVICES"),
            "ANDROID_USE_SCRCPY_RESIDENT_SERIALS": mcp.os.environ.get("ANDROID_USE_SCRCPY_RESIDENT_SERIALS"),
        }
        captured: dict[str, str] = {}
        try:
            for key in original_env:
                mcp.os.environ.pop(key, None)
            mcp.read_user_env_values = lambda: {
                "ANDROID_USE_WIRELESS_DEVICES": "10.0.0.1:1111,10.0.0.2:2222",
                "ANDROID_USE_SCRCPY_RESIDENT_SERIALS": "10.0.0.1:1111,usb-1",
            }
            mcp.update_user_env_file = lambda updates: captured.update(updates)

            mcp.save_wireless_config("10.0.0.1", 5555, "10.0.0.1:5555")
        finally:
            mcp.read_user_env_values = original_read
            mcp.update_user_env_file = original_update
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(captured["ANDROID_USE_WIRELESS_DEVICES"], "10.0.0.2:2222,10.0.0.1:5555")
        self.assertEqual(captured["ANDROID_USE_SCRCPY_RESIDENT_SERIALS"], "usb-1,10.0.0.1:5555")

    def test_wireless_reconnect_all_uses_saved_configs(self) -> None:
        original_configs = mcp.wireless_configs_from_env
        original_reconnect = mcp.wireless_reconnect
        calls: list[dict[str, object]] = []
        try:
            mcp.wireless_configs_from_env = lambda: [
                {"host": "10.0.0.1", "port": 5555, "serial": "10.0.0.1:5555"},
                {"host": "10.0.0.2", "port": 4444, "serial": "10.0.0.2:4444"},
            ]

            def fake_reconnect(**kwargs: object) -> dict[str, object]:
                calls.append(kwargs)
                return {"ok": True, "serial": kwargs["serial"]}

            mcp.wireless_reconnect = fake_reconnect
            result = mcp.wireless_reconnect_all(save=False, start_scrcpy=True)
        finally:
            mcp.wireless_configs_from_env = original_configs
            mcp.wireless_reconnect = original_reconnect

        self.assertEqual(result["count"], 2)
        self.assertEqual([call["serial"] for call in calls], ["10.0.0.1:5555", "10.0.0.2:4444"])
        self.assertTrue(all(call["start_scrcpy"] for call in calls))
        self.assertTrue(all(call["save"] is False for call in calls))

    def test_choose_serial_dedupes_usb_and_wireless_same_device(self) -> None:
        original_list_devices = mcp.list_devices
        original_shell = mcp.shell
        original_auto_reconnect = mcp.auto_reconnect_wireless_if_needed
        original_env = {
            "ANDROID_USE_SERIAL": mcp.os.environ.get("ANDROID_USE_SERIAL"),
            "ANDROID_SERIAL": mcp.os.environ.get("ANDROID_SERIAL"),
        }
        try:
            mcp.os.environ.pop("ANDROID_USE_SERIAL", None)
            mcp.os.environ.pop("ANDROID_SERIAL", None)
            mcp.list_devices = lambda: [
                {"serial": "ANMB9X5A10G00857", "state": "device"},
                {"serial": "172.27.31.51:5555", "state": "device"},
            ]
            mcp.shell = lambda serial, command, timeout=30: "ANMB9X5A10G00857"
            mcp.auto_reconnect_wireless_if_needed = lambda: None

            self.assertEqual(mcp.choose_serial(), "172.27.31.51:5555")
        finally:
            mcp.list_devices = original_list_devices
            mcp.shell = original_shell
            mcp.auto_reconnect_wireless_if_needed = original_auto_reconnect
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

    def test_parse_screen_size_prefers_override(self) -> None:
        size = mcp.parse_screen_size("Physical size: 1080x2400\nOverride size: 720x1600")

        self.assertEqual(size, {"width": 720, "height": 1600})

    def test_tool_appshot_saves_evidence_bundle(self) -> None:
        original_choose = mcp.choose_serial
        original_screenshot = mcp.screenshot_png
        original_observe = mcp.observe_ui
        png = make_png(1080, 2400)
        try:
            mcp.choose_serial = lambda _serial=None: "device-1"
            mcp.screenshot_png = lambda serial: png

            def fake_observe(serial: str, include_xml: bool = False, limit: int = 160) -> dict[str, object]:
                ui: dict[str, object] = {
                    "nodes": [
                        {
                            "index": 0,
                            "text": "登录",
                            "resource_id": "com.example:id/login",
                            "bounds": {"left": 10, "top": 20, "right": 110, "bottom": 80},
                            "center": {"x": 60, "y": 50},
                            "clickable": True,
                        }
                    ],
                    "count": 1,
                }
                if include_xml:
                    ui["xml"] = "<hierarchy />"
                return {
                    "state": {"serial": serial, "focused_window": "com.example/.MainActivity"},
                    "ui": ui,
                }

            mcp.observe_ui = fake_observe

            with tempfile.TemporaryDirectory() as tmpdir:
                content = mcp.tool_appshot({"serial": "device-1", "include_xml": True, "save_dir": tmpdir})
                payload = json.loads(content[0]["text"])
                saved_json = Path(payload["paths"]["json"])
                saved_png = Path(payload["paths"]["png"])

                self.assertEqual(content[1]["type"], "image")
                self.assertEqual(payload["kind"], "android_appshot")
                self.assertEqual(payload["screenshot"]["screen"], {"width": 1080, "height": 2400})
                self.assertEqual(payload["ui"]["count"], 1)
                self.assertEqual(payload["ui"]["xml"], "<hierarchy />")
                self.assertTrue(saved_json.exists())
                self.assertEqual(saved_png.read_bytes(), png)
                self.assertEqual(json.loads(saved_json.read_text())["kind"], "android_appshot")
        finally:
            mcp.choose_serial = original_choose
            mcp.screenshot_png = original_screenshot
            mcp.observe_ui = original_observe

    def test_tool_appshot_returns_screenshot_when_ui_dump_fails(self) -> None:
        original_choose = mcp.choose_serial
        original_screenshot = mcp.screenshot_png
        original_observe = mcp.observe_ui
        original_state = mcp.device_state
        try:
            mcp.choose_serial = lambda _serial=None: "device-1"
            mcp.screenshot_png = lambda serial: make_png(720, 1280)
            mcp.observe_ui = lambda *args, **kwargs: (_ for _ in ()).throw(mcp.AndroidUseError("dump failed"))
            mcp.device_state = lambda serial: {"serial": serial, "focused_window": "com.example/.MainActivity"}

            content = mcp.tool_appshot({"save": False, "include_image": False})
            payload = json.loads(content[0]["text"])
        finally:
            mcp.choose_serial = original_choose
            mcp.screenshot_png = original_screenshot
            mcp.observe_ui = original_observe
            mcp.device_state = original_state

        self.assertEqual(len(content), 1)
        self.assertEqual(payload["kind"], "android_appshot")
        self.assertEqual(payload["ui"]["count"], 0)
        self.assertIn("dump failed", payload["ui_error"])

    def test_keycode_normalization(self) -> None:
        self.assertEqual(mcp.keycode("back"), "KEYCODE_BACK")
        self.assertEqual(mcp.keycode("KEYCODE_HOME"), "KEYCODE_HOME")
        self.assertEqual(mcp.keycode(66), "66")
        self.assertEqual(mcp.keycode("camera"), "KEYCODE_CAMERA")

    def test_type_text_uses_adb_keyboard_switch_for_unicode(self) -> None:
        original_current_ime = mcp.current_input_method
        original_list_imes = mcp.list_input_methods
        original_set_ime = mcp.set_input_method
        original_shell = mcp.shell
        original_env = {
            "ANDROID_USE_WEBVIEW_DIRECT_INPUT": mcp.os.environ.get("ANDROID_USE_WEBVIEW_DIRECT_INPUT"),
            "ANDROID_USE_FAST_INPUT_IME": mcp.os.environ.get("ANDROID_USE_FAST_INPUT_IME"),
            "ANDROID_USE_RESTORE_IME_AFTER_TYPE": mcp.os.environ.get("ANDROID_USE_RESTORE_IME_AFTER_TYPE"),
        }
        state = {"ime": "com.google.android.inputmethod.pinyin/.PinyinIME"}
        commands: list[str] = []
        try:
            mcp.os.environ["ANDROID_USE_WEBVIEW_DIRECT_INPUT"] = "0"
            mcp.os.environ["ANDROID_USE_FAST_INPUT_IME"] = "1"
            mcp.os.environ["ANDROID_USE_RESTORE_IME_AFTER_TYPE"] = "0"
            mcp.current_input_method = lambda serial: state["ime"]
            mcp.list_input_methods = lambda serial: ["com.github.uiautomator/.AdbKeyboard"]
            mcp.set_input_method = lambda serial, ime: state.update({"ime": ime}) or commands.append(f"ime set {ime}")
            mcp.shell = lambda serial, command, timeout=30: commands.append(command) or ""

            method = mcp.type_focused_text_fast("device-1", "你好", clear_first=True, enter=True)
        finally:
            mcp.current_input_method = original_current_ime
            mcp.list_input_methods = original_list_imes
            mcp.set_input_method = original_set_ime
            mcp.shell = original_shell
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(method, "adb_keyboard_switch")
        self.assertEqual(state["ime"], "com.github.uiautomator/.AdbKeyboard")
        self.assertTrue(any("ADB_CLEAR_TEXT" in command for command in commands))
        self.assertTrue(any("ADB_INPUT_TEXT" in command and "你好" in command for command in commands))

    def test_type_text_batch_fallback_uses_one_shell_call_for_clear(self) -> None:
        original_broadcast = mcp.adb_keyboard_broadcast_text
        original_shell = mcp.shell
        original_env = {"ANDROID_USE_WEBVIEW_DIRECT_INPUT": mcp.os.environ.get("ANDROID_USE_WEBVIEW_DIRECT_INPUT")}
        commands: list[str] = []
        try:
            mcp.os.environ["ANDROID_USE_WEBVIEW_DIRECT_INPUT"] = "0"
            mcp.adb_keyboard_broadcast_text = lambda *args, **kwargs: False
            mcp.shell = lambda serial, command, timeout=30: commands.append(command) or ""

            method = mcp.type_focused_text_fast("device-1", "hello world", clear_first=True, clear_count=3, enter=True)
        finally:
            mcp.adb_keyboard_broadcast_text = original_broadcast
            mcp.shell = original_shell
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(method, "adb_shell_batch")
        self.assertEqual(len(commands), 1)
        self.assertIn("input keyevent KEYCODE_MOVE_END", commands[0])
        self.assertIn("input keyevent KEYCODE_DEL KEYCODE_DEL KEYCODE_DEL", commands[0])
        self.assertIn("input text hello%sworld", commands[0])
        self.assertIn("input keyevent KEYCODE_ENTER", commands[0])

    def test_type_text_prefers_webview_dom_input(self) -> None:
        original_type_webview = mcp.type_webview_text_fast
        original_shell_batch = mcp.adb_shell_batch_type_text
        original_env = {"ANDROID_USE_WEBVIEW_DIRECT_INPUT": mcp.os.environ.get("ANDROID_USE_WEBVIEW_DIRECT_INPUT")}
        calls: list[dict[str, object]] = []
        try:
            mcp.os.environ["ANDROID_USE_WEBVIEW_DIRECT_INPUT"] = "1"

            def fake_type_webview(serial: str, text: str, **kwargs: object) -> str:
                calls.append({"serial": serial, "text": text, **kwargs})
                return "webview_dom_dom_value"

            mcp.type_webview_text_fast = fake_type_webview
            mcp.adb_shell_batch_type_text = lambda *args, **kwargs: self.fail("keyboard fallback should not run")
            method = mcp.type_focused_text_fast("device-1", "hello", clear_first=True, enter=True)
        finally:
            mcp.type_webview_text_fast = original_type_webview
            mcp.adb_shell_batch_type_text = original_shell_batch
            for key, value in original_env.items():
                if value is None:
                    mcp.os.environ.pop(key, None)
                else:
                    mcp.os.environ[key] = value

        self.assertEqual(method, "webview_dom_dom_value")
        self.assertEqual(calls, [{"serial": "device-1", "text": "hello", "clear_first": True, "enter": True}])

    def test_recipe_type_text_uses_fast_typing_path(self) -> None:
        original_type_fast = mcp.type_focused_text_fast
        calls: list[dict[str, object]] = []
        try:
            def fake_type_fast(serial: str, text: str, **kwargs: object) -> str:
                calls.append({"serial": serial, "text": text, **kwargs})
                return "fake_fast"

            mcp.type_focused_text_fast = fake_type_fast
            result = mcp.execute_recipe_step(
                "device-1",
                {"action": "type_text", "text": "hello", "clear_first": True, "clear_count": 2, "enter": True},
            )
        finally:
            mcp.type_focused_text_fast = original_type_fast

        self.assertEqual(result["method"], "fake_fast")
        self.assertEqual(calls, [
            {"serial": "device-1", "text": "hello", "clear_first": True, "clear_count": 2, "enter": True}
        ])

    def test_extract_json_object_from_markdown(self) -> None:
        action = mcp.extract_json_object('```json\n{"action":"tap","x":1,"y":2}\n```')

        self.assertEqual(action["action"], "tap")
        self.assertEqual(action["x"], 1)

    def test_parse_tars_click_absolute(self) -> None:
        action = mcp.parse_tars_action_response(
            "Thought: tap the tab\nAction: click(point='430 2465')",
            {"width": 1440, "height": 2560},
            coordinate_mode="absolute",
        )

        self.assertEqual(action["action"], "tap")
        self.assertEqual(action["x"], 430)
        self.assertEqual(action["y"], 2465)

    def test_parse_tars_click_normalized(self) -> None:
        action = mcp.parse_tars_action_response(
            "Thought: tap the tab\nAction: click(point='500 900')",
            {"width": 1440, "height": 2560},
            coordinate_mode="normalized_1000",
        )

        self.assertEqual(action["action"], "tap")
        self.assertEqual(action["x"], 720)
        self.assertEqual(action["y"], 2304)

    def test_parse_tars_mobile_actions(self) -> None:
        typed = mcp.parse_tars_action_response(
            "Thought: submit\nAction: type(content='hello\\n')",
            {"width": 1440, "height": 2560},
        )
        back = mcp.parse_tars_action_response("Thought: go back\nAction: press_back()", {"width": 1, "height": 1})
        finished = mcp.parse_tars_action_response(
            "Thought: done\nAction: finished(content='完成')",
            {"width": 1, "height": 1},
        )

        self.assertEqual(typed["action"], "type_text")
        self.assertTrue(typed["enter"])
        self.assertEqual(back["key"], "BACK")
        self.assertEqual(finished["action"], "done")

    def test_parse_ui_nodes_and_find_text(self) -> None:
        xml = """<hierarchy rotation="0">
  <node text="" content-desc="" resource-id="" class="android.widget.FrameLayout" bounds="[0,0][1440,2560]" clickable="false" enabled="true">
    <node text="首页" content-desc="" resource-id="com.example:id/home" class="android.widget.TextView" bounds="[80,2400][220,2520]" clickable="true" enabled="true" selected="true" />
    <node text="发现" content-desc="" resource-id="com.example:id/discover" class="android.widget.TextView" bounds="[920,2400][1080,2520]" clickable="true" enabled="true" selected="false" />
    <node text="" content-desc="" resource-id="com.example:id/check" class="android.widget.CheckBox" bounds="[100,100][140,140]" clickable="true" enabled="true" checkable="true" checked="true" />
  </node>
</hierarchy>"""
        nodes = mcp.parse_ui_nodes(xml)
        node = mcp.find_ui_node(nodes, "发现")
        point = mcp.node_click_point(node)
        checkbox = mcp.find_node_by_selector(nodes, {"strategy": "resource_id", "value": "com.example:id/check"})

        self.assertIsNotNone(node)
        self.assertEqual(point, {"x": 1000, "y": 2460})
        self.assertEqual(mcp.find_node_by_selector(nodes, {"strategy": "resource_id", "value": "com.example:id/discover"}), node)
        self.assertTrue(checkbox["checkable"])
        self.assertTrue(checkbox["checked"])

    def test_parse_webview_devtools_sockets_deduplicates(self) -> None:
        proc_net_unix = """
0000000000000000: 00000002 00000000 00010000 0001 01 30085153 @webview_devtools_remote_twe_32675
0000000000000000: 00000003 00000000 00000000 0001 03 30856838 @webview_devtools_remote_twe_32675
0000000000000000: 00000002 00000000 00010000 0001 01 30085154 @webview_devtools_remote_123
"""

        sockets = mcp.parse_webview_devtools_sockets(proc_net_unix)

        self.assertEqual(sockets, ["webview_devtools_remote_twe_32675", "webview_devtools_remote_123"])

    def test_normalize_xiaoluxue_knowledge_index(self) -> None:
        self.assertEqual(mcp.normalize_xiaoluxue_knowledge_index("1.1.11"), "1111")
        self.assertEqual(mcp.normalize_xiaoluxue_knowledge_index("1.1.1.1"), "1111")

    def test_xiaoluxue_app_only_url_detection(self) -> None:
        self.assertTrue(mcp.is_xiaoluxue_app_only_url("https://stu.xiaoluxue.com/course?knowledgeId=3785"))
        self.assertTrue(mcp.is_xiaoluxue_app_only_url("http://stu.test.xiaoluxue.cn/exercise?studySessionId=1"))
        self.assertTrue(mcp.is_xiaoluxue_app_only_url("https://gw-stu.test.xiaoluxue.cn/path"))
        self.assertFalse(mcp.is_xiaoluxue_app_only_url("https://example.com/course"))
        self.assertFalse(mcp.is_xiaoluxue_app_only_url("xlx://router/vessel/webview"))

    def test_xiaoluxue_url_kind_supports_test_hosts(self) -> None:
        self.assertEqual(mcp.xiaoluxue_url_kind("http://stu.test.xiaoluxue.cn/course?knowledgeId=1"), "course")
        self.assertEqual(mcp.xiaoluxue_url_kind("http://stu.test.xiaoluxue.cn/exercise?studySessionId=1"), "exercise")
        self.assertEqual(mcp.xiaoluxue_url_kind("https://stu.xiaoluxue.com/"), "any")
        self.assertIsNone(mcp.xiaoluxue_url_kind("https://example.com/course"))

    def test_xiaoluxue_vessel_route_quotes_target(self) -> None:
        route = mcp.xiaoluxue_vessel_webview_url("https://gw-stu.test.xiaoluxue.cn/course?a=1&b=数学")

        self.assertTrue(route.startswith("xlx://router/vessel/webview?url="))
        self.assertIn("gw-stu.test.xiaoluxue.cn%2Fcourse", route)
        self.assertIn("full_screen=true", route)
        self.assertIn("title_bar=false", route)

    def test_xiaoluxue_runtime_url_matches_course_identity(self) -> None:
        target = "https://stu.xiaoluxue.com/course?knowledgeId=3785&lessonId=1"
        current = "https://stu.xiaoluxue.com/course?lessonId=1&knowledgeId=3785&redirectWidgetIndex=4"

        self.assertTrue(mcp.xiaoluxue_runtime_url_matches(target, current))
        self.assertFalse(mcp.xiaoluxue_runtime_url_matches(target, "https://stu.xiaoluxue.com/course?knowledgeId=9999&lessonId=1"))

    def test_xiaoluxue_rebase_h5_url_uses_current_test_host(self) -> None:
        target = "https://stu.xiaoluxue.com/course?knowledgeId=3785&lessonId=1"
        current = "http://stu.test.xiaoluxue.cn/exercise?studySessionId=1"

        self.assertEqual(
            mcp.xiaoluxue_rebase_h5_url(target, current),
            "http://stu.test.xiaoluxue.cn/course?knowledgeId=3785&lessonId=1",
        )

    def test_xiaoluxue_native_scaled_point(self) -> None:
        self.assertEqual(
            mcp.xiaoluxue_native_scaled_point((690, 280), {"width": 2000, "height": 1200}),
            (690, 280),
        )
        self.assertEqual(
            mcp.xiaoluxue_native_scaled_point((690, 280), {"width": 1000, "height": 600}),
            (345, 140),
        )

    def test_xiaoluxue_map_instruction_and_action_normalization(self) -> None:
        self.assertTrue(mcp.xiaoluxue_instruction_looks_like_map("进入 1.5 题型突破"))
        self.assertTrue(mcp.xiaoluxue_instruction_looks_like_map("进入数学的巩固练习，随便一节课"))
        self.assertFalse(mcp.xiaoluxue_instruction_looks_like_map("首页 -> 数学 1.1.11 知识讲解 2x"))
        self.assertEqual(mcp.normalize_xiaoluxue_map_index("进入 1.5 题型突破"), "1.5")
        self.assertEqual(mcp.normalize_xiaoluxue_map_action("打开 1.5 错题"), "wrong")
        self.assertEqual(mcp.normalize_xiaoluxue_map_action("打开 1.5 笔记本"), "notebook")
        self.assertEqual(mcp.normalize_xiaoluxue_map_action("看报告"), "report")
        self.assertEqual(mcp.normalize_xiaoluxue_map_action("进入数学 专属精练"), "expand")
        self.assertEqual(mcp.normalize_xiaoluxue_map_action("进入数学 巩固练习"), "expand")
        self.assertEqual(mcp.normalize_xiaoluxue_lesson_action("直接练"), "direct_practice")
        self.assertEqual(mcp.normalize_xiaoluxue_lesson_action("继续到下一题"), "continue_answer")
        self.assertEqual(mcp.normalize_xiaoluxue_lesson_action("完成返回地图"), "finish_result")
        self.assertEqual(mcp.normalize_xiaoluxue_subject_id("进入语文 1.5 题型突破"), 1)
        self.assertEqual(mcp.normalize_xiaoluxue_subject_id("打开 subject_id=2 地图"), 2)
        self.assertEqual(
            mcp.xiaoluxue_study_subject_route_url(1),
            "xlx://router/study/subject?subject_id=1",
        )
        self.assertEqual(
            mcp.xiaoluxue_map_fast_action_from_instruction("进入语文 1.5 题型突破"),
            {
                "action": "xiaoluxue_map_fast_path",
                "instruction": "进入语文 1.5 题型突破",
                "action_name": "practise",
                "source": "xiaoluxue-native-map",
                "index": "1.5",
                "subject_id": 1,
                "route_if_subject": True,
            },
        )
        self.assertEqual(
            mcp.xiaoluxue_map_fast_action_from_instruction("进入数学 1.5 题型突破 直接练"),
            {
                "action": "xiaoluxue_map_fast_path",
                "instruction": "进入数学 1.5 题型突破 直接练",
                "action_name": "practise",
                "source": "xiaoluxue-native-map",
                "index": "1.5",
                "subject_id": 2,
                "route_if_subject": True,
                "enter_direct_practice": True,
            },
        )
        self.assertEqual(
            mcp.xiaoluxue_map_fast_action_from_instruction("进入数学 专属精练"),
            {
                "action": "xiaoluxue_map_fast_path",
                "instruction": "进入数学 专属精练",
                "action_name": "expand",
                "source": "xiaoluxue-native-map",
                "subject_id": 2,
                "route_if_subject": True,
            },
        )
        self.assertEqual(
            mcp.xiaoluxue_lesson_fast_action_from_instruction("进入 直接练"),
            {
                "action": "xiaoluxue_lesson_fast_path",
                "instruction": "进入 直接练",
                "action_name": "direct_practice",
                "source": "xiaoluxue-native-lesson",
            },
        )
        self.assertEqual(
            mcp.xiaoluxue_lesson_fast_action_from_instruction("完成返回地图"),
            {
                "action": "xiaoluxue_lesson_fast_path",
                "instruction": "完成返回地图",
                "action_name": "finish_result",
                "source": "xiaoluxue-native-lesson",
            },
        )

    def test_xiaoluxue_native_course_sequence_taps_continue_quickly(self) -> None:
        original_tap = mcp.xiaoluxue_native_tap
        original_wait = mcp.xiaoluxue_wait_for_site_page
        original_sleep = mcp.time.sleep
        labels: list[str] = []
        try:
            mcp.xiaoluxue_native_tap = lambda serial, point, info, label, steps, started_at: labels.append(label)
            mcp.xiaoluxue_wait_for_site_page = lambda serial, deadline: {"id": "page", "url": "http://stu.test/course"}
            mcp.time.sleep = lambda seconds: None

            result = mcp.xiaoluxue_try_native_course_sequence(
                "serial",
                {"width": 2000, "height": 1200},
                [],
                0.0,
                999999999.0,
                label="subject_map",
                tap_math=False,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(
                labels,
                [
                    "subject_map:dismiss_progress_popup",
                    "subject_map:guide_bubble",
                    "subject_map:continue:1",
                ],
            )
        finally:
            mcp.xiaoluxue_native_tap = original_tap
            mcp.xiaoluxue_wait_for_site_page = original_wait
            mcp.time.sleep = original_sleep

    def test_xiaoluxue_open_knowledge_prefers_native_entry_before_vessel(self) -> None:
        original_any_page = mcp.xiaoluxue_any_page
        original_native_entry = mcp.xiaoluxue_open_native_course_entry
        original_vessel_entry = mcp.xiaoluxue_open_vessel_course_page
        original_cdp_eval = mcp.cdp_eval_value
        calls: list[str] = []
        target_url = str(mcp.XIAOLUXUE_KNOWLEDGE_SHORTCUTS[(2, "1111")]["targetUrl"])
        fake_page = {
            "id": "page-1",
            "url": target_url,
            "runtimeHref": target_url,
            "webSocketDebuggerUrl": "ws://127.0.0.1:1/devtools/page/page-1",
        }
        try:
            mcp.xiaoluxue_any_page = lambda *args, **kwargs: (_ for _ in ()).throw(mcp.AndroidUseError("no current page"))

            def fake_native_entry(*args, **kwargs):
                calls.append("native")
                return {"attempted": True, "ok": True, "page": fake_page}

            def fake_vessel_entry(*args, **kwargs):
                calls.append("vessel")
                raise AssertionError("vessel should not be attempted before successful native entry")

            def fake_cdp_eval(page, expression, **kwargs):
                if expression == "location.href":
                    return target_url
                text = str(expression)
                if "readyState" in text and "targetWidget" not in text:
                    return {"ok": True, "before": {"readyState": "complete"}, "after": {"readyState": "complete"}}
                if "targetWidget" in text:
                    return {
                        "ok": True,
                        "readyState": "complete",
                        "targetWidget": {"dataName": "初识集合——集合与元素的定义", "loaded": True},
                        "videos": [{"playbackRate": 2}],
                    }
                if "turbo" in text or "video" in text:
                    return {"ok": True, "video": True}
                return {"ok": True}

            mcp.xiaoluxue_open_native_course_entry = fake_native_entry
            mcp.xiaoluxue_open_vessel_course_page = fake_vessel_entry
            mcp.cdp_eval_value = fake_cdp_eval

            result = mcp.run_xiaoluxue_open_knowledge_guide(
                "serial",
                {
                    "subject_id": 2,
                    "knowledge_index": "1.1.11",
                    "rate": 2,
                    "timeout_sec": 3,
                    "prefer_native_entry_first": True,
                },
                record=False,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(calls, ["native"])
            self.assertTrue(result["native_entry"]["ok"])
            self.assertFalse(result["vessel_entry"]["attempted"])
        finally:
            mcp.xiaoluxue_any_page = original_any_page
            mcp.xiaoluxue_open_native_course_entry = original_native_entry
            mcp.xiaoluxue_open_vessel_course_page = original_vessel_entry
            mcp.cdp_eval_value = original_cdp_eval

    def test_xiaoluxue_open_knowledge_prefers_direct_vessel_for_known_shortcut_by_default(self) -> None:
        original_any_page = mcp.xiaoluxue_any_page
        original_native_entry = mcp.xiaoluxue_open_native_course_entry
        original_vessel_entry = mcp.xiaoluxue_open_vessel_course_page
        original_cdp_eval = mcp.cdp_eval_value
        calls: list[str] = []
        captured_timeout: list[float] = []
        target_url = str(mcp.XIAOLUXUE_KNOWLEDGE_SHORTCUTS[(2, "1111")]["targetUrl"])
        fake_page = {
            "id": "page-1",
            "url": target_url,
            "runtimeHref": target_url,
            "webSocketDebuggerUrl": "ws://127.0.0.1:1/devtools/page/page-1",
        }
        try:
            mcp.xiaoluxue_any_page = lambda *args, **kwargs: (_ for _ in ()).throw(mcp.AndroidUseError("no current page"))

            def fake_native_entry(*args, **kwargs):
                calls.append("native")
                raise AssertionError("native should not be attempted for a known shortcut by default")

            def fake_vessel_entry(*args, **kwargs):
                calls.append("vessel")
                captured_timeout.append(float(kwargs["timeout_sec"]))
                return {"attempted": True, "ok": True, "page": fake_page}

            def fake_cdp_eval(page, expression, **kwargs):
                if expression == "location.href":
                    return target_url
                text = str(expression)
                if "readyState" in text and "targetWidget" not in text:
                    return {"ok": True, "before": {"readyState": "complete"}, "after": {"readyState": "complete"}}
                if "targetWidget" in text:
                    return {
                        "ok": True,
                        "readyState": "complete",
                        "targetWidget": {"dataName": "初识集合——集合与元素的定义", "loaded": True},
                        "videos": [{"playbackRate": 2}],
                    }
                if "turbo" in text or "video" in text:
                    return {"ok": True, "video": True}
                return {"ok": True}

            mcp.xiaoluxue_open_native_course_entry = fake_native_entry
            mcp.xiaoluxue_open_vessel_course_page = fake_vessel_entry
            mcp.cdp_eval_value = fake_cdp_eval

            result = mcp.run_xiaoluxue_open_knowledge_guide(
                "serial",
                {"subject_id": 2, "knowledge_index": "1.1.11", "rate": 2, "timeout_sec": 5},
                record=False,
            )

            self.assertTrue(result["ok"])
            self.assertEqual(calls, ["vessel"])
            self.assertGreaterEqual(captured_timeout[0], 4.0)
            self.assertTrue(result["vessel_entry"]["ok"])
            self.assertFalse(result["native_entry"]["attempted"])
            self.assertEqual(result["stop_loading"]["skipped"], "entry-opened-target-course")
            self.assertEqual(result["prefetch"]["skipped"], "entry-opened-target-course")
            self.assertEqual(result["rate_prepare"]["skipped"], "entry-opened-target-course")
        finally:
            mcp.xiaoluxue_any_page = original_any_page
            mcp.xiaoluxue_open_native_course_entry = original_native_entry
            mcp.xiaoluxue_open_vessel_course_page = original_vessel_entry
            mcp.cdp_eval_value = original_cdp_eval

    def test_xiaoluxue_hidden_course_webview_behind_native_map_is_not_foreground(self) -> None:
        original_focus = mcp.get_focused_window
        try:
            mcp.get_focused_window = lambda serial: (
                f"Window{{1 u0 {mcp.XIAOLUXUE_STUDENT_PACKAGE}/{mcp.XIAOLUXUE_STUDY_SUBJECT_ACTIVITY}}}"
            )
            with self.assertRaises(mcp.AndroidUseError):
                mcp.xiaoluxue_ensure_foreground_webview(
                    "serial",
                    {
                        "url": "https://stu.xiaoluxue.com/course?knowledgeId=3785",
                        "descriptionParsed": {"visible": False},
                    },
                )
        finally:
            mcp.get_focused_window = original_focus

    def test_xiaoluxue_hidden_course_webview_behind_leakcanary_is_not_foreground(self) -> None:
        original_focus = mcp.get_focused_window
        try:
            mcp.get_focused_window = lambda serial: (
                f"{mcp.XIAOLUXUE_STUDENT_PACKAGE}/leakcanary.internal.activity.LeakLauncherActivity"
            )
            with self.assertRaises(mcp.AndroidUseError):
                mcp.xiaoluxue_ensure_foreground_webview(
                    "serial",
                    {
                        "url": "https://stu.xiaoluxue.com/course?knowledgeId=3785",
                        "descriptionParsed": {"visible": False},
                    },
                )
        finally:
            mcp.get_focused_window = original_focus

    def test_xiaoluxue_wait_for_target_course_page_accepts_static_target_url_after_eval_race(self) -> None:
        original_discover = mcp.discover_webview_pages
        original_eval = mcp.cdp_eval_value
        original_sleep = mcp.time.sleep
        original_monotonic = mcp.time.monotonic
        calls = 0
        page = {
            "id": "page-1",
            "url": "https://stu.xiaoluxue.com/course?knowledgeId=3785&lessonId=1",
            "webSocketDebuggerUrl": "ws://127.0.0.1/devtools/page/page-1",
            "descriptionParsed": {"visible": True},
        }
        try:
            mcp.discover_webview_pages = lambda serial: [page]
            mcp.cdp_eval_value = lambda *args, **kwargs: (_ for _ in ()).throw(mcp.AndroidUseError("runtime href race"))
            mcp.time.sleep = lambda seconds: None

            def fake_monotonic() -> float:
                nonlocal calls
                calls += 1
                return 0.0 if calls <= 2 else 1.0

            mcp.time.monotonic = fake_monotonic

            result = mcp.xiaoluxue_wait_for_target_course_page(
                "serial",
                0.5,
                knowledge_id=3785,
                poll_interval=0,
            )

            self.assertEqual(result["url"], page["url"])
        finally:
            mcp.discover_webview_pages = original_discover
            mcp.cdp_eval_value = original_eval
            mcp.time.sleep = original_sleep
            mcp.time.monotonic = original_monotonic

    def test_xiaoluxue_route_app_url_uses_scheme_proxy_component(self) -> None:
        original_adb = mcp.adb
        commands: list[list[str]] = []
        try:
            mcp.adb = lambda command, serial=None, timeout=30: commands.append(list(command)) or b"Starting: Intent {}"

            result = mcp.xiaoluxue_route_app_url(
                "serial",
                "https://stu.xiaoluxue.com/course?knowledgeId=3785",
                force_stop=True,
            )

            command = commands[0]
            self.assertTrue(result["ok"])
            self.assertIn("-S", command)
            self.assertIn("-n", command)
            self.assertIn(f"{mcp.XIAOLUXUE_STUDENT_PACKAGE}/{mcp.XIAOLUXUE_SCHEME_PROXY_ACTIVITY}", command)
            self.assertNotIn("-p", command)
        finally:
            mcp.adb = original_adb
